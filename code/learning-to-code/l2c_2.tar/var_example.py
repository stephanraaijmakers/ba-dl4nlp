def f():
    print(txt)

    def g():
        print(txt)
    g()    


txt="Deep learning for NLP"


f()
