class my_ML:
      txt="start"
      def __init__(self,s):
      	    self.txt = s

      def run(self):
            print("After class assignment:",self.txt)


ml=my_ML("deep learning rules")

ml.run()


      	  
         
